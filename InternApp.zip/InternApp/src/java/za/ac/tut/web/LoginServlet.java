/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author charles
 */
public class LoginServlet extends HttpServlet {

 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
//        if (validUser(username, password)) {
            RequestDispatcher disp = request.getRequestDispatcher("menu.jsp");
            disp.forward(request, response);
//        }
//        else{
//            RequestDispatcher disp = request.getRequestDispatcher("login.jsp");
//            disp.forward(request, response);
//        }
    }
    
    private boolean validUser(String username,String password){
        try {
            Connection conn = getConnection();
            String sql ="SELECT * FROM interndb.users WHERE username=? AND password=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;   
    }
    
    private Connection getConnection() throws SQLException {
    String url = "jdbc:mysql://localhost:3306/interndb";
    String user = "root";
    String password = "root";
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(url, user, password);
    } catch (ClassNotFoundException ex) {
        throw new SQLException("Failed to load MySQL JDBC Driver", ex);
    } catch (SQLException ex) {
        throw new SQLException("Failed to connect to MySQL database", ex);
    }
    }

}