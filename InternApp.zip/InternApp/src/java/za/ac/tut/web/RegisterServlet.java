/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author charles
 */
public class RegisterServlet extends HttpServlet {

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password"); 
        boolean isRegistered=registerUser(username,password);
        if(isRegistered){
            HttpSession session=request.getSession(true);
            
            session.setAttribute("LoggedIn", true);
              RequestDispatcher disp=request.getRequestDispatcher("register_outcome.jsp");
    disp.forward(request, response);
        }else{
            request.setAttribute("registeredError","Failed to register.Please try again .");
              RequestDispatcher disp=request.getRequestDispatcher("register.jsp");
    disp.forward(request, response);
            
        }
    }
    private boolean registerUser(String username,String password){
        
        try {
            String url="jdbc:derby://localhost:1527/InternDB";
        String user="charles";
         String dbPassword="123" ;
         
            Connection connection=DriverManager.getConnection(url, user, dbPassword);
            String sql="INSERT INTO USERS(USERNAME,PASSWORD) VALUES(?,?)";
            PreparedStatement ps=connection.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
           int rowsInserted=ps.executeUpdate();
           return rowsInserted>0;
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
             return false;
        }
        }
}
